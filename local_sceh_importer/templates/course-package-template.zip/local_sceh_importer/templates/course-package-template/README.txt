SCEH Course Package Template
============================
Template Version: 1.0
Last Updated: 2026-02-18

This folder structure shows you exactly how to organize your course content for import.

NOTE: This README.txt file is automatically ignored during import - no need to delete it!


FOLDER STRUCTURE
----------------

Use numbered folders for weeks and days:
  01. Week 1/
    01. Day 1/
    02. Day 2/
  02. Week 2/
    01. Day 1/

The numbers control the order. The text after the number is the display name.


CONTENT FOLDERS
---------------

Inside each day folder, create these subfolders as needed:

  content/          - Learner materials (PDFs, videos, documents)
  lesson_plan/      - Trainer guides (visible only to trainers)
  quiz/             - Quiz files in CSV format
  assignment/       - Assignment instructions (PDFs, documents)
  roleplay/         - Roleplay scenarios (visible only to trainers)
  rubric/           - Grading rubrics (visible only to trainers)


ADDING LINKS (YouTube, External URLs)
--------------------------------------

To add YouTube videos or external links, create a links.csv file in any content folder:

  01. Week 1/
    01. Day 1/
      content/
        links.csv          - YouTube and external links
        Introduction.pdf   - Regular file

CSV format (see links.csv example in this template):
  order,title,url,type,audience,notes
  10,Video Title,https://youtube.com/watch?v=...,video,learner,
  20,Reference Doc,https://docs.example.com,doc,learner,

Columns:
  - order: Number for sorting (use gaps like 10, 20, 30)
  - title: Display name for the link
  - url: Full URL (YouTube, Google Docs, any website)
  - type: Optional label (video, doc, etc.) - for your reference only
  - audience: learner or trainer (default: learner)
  - notes: Optional notes (not shown to users)

YouTube videos are automatically embedded. Other URLs open in a new window.


QUIZ FORMAT
-----------

Quizzes must be CSV files with these columns:
  - question_type (multichoice, truefalse, shortanswer, essay)
  - question_text
  - option_a, option_b, option_c, option_d (for multichoice)
  - correct_answer
  - points

See template_quiz.csv in this folder for a working example with all question types.

Place your quiz CSV files in the quiz/ folder inside each day.


FILE TYPES SUPPORTED
--------------------

Documents: .pdf, .doc, .docx, .ppt, .pptx, .txt
Media: .mp4, .mov, .mp3, .wav
Quizzes: .csv


TIPS
----

1. You don't need all folders - only create the ones you need
2. File names become activity names (e.g., "Introduction.pdf" → "Introduction")
3. Use clear, descriptive file names
4. Keep folder names short but meaningful
5. Use links.csv for YouTube videos and external resources
6. Delete example files (links.csv, template_quiz.csv) before zipping if not needed


NEED HELP?
----------

Contact your system administrator or refer to the import documentation.
