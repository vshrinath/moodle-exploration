SCEH Course Package Template
============================

This folder structure shows you exactly how to organize your course content for import.

IMPORTANT: Delete this README.txt file before zipping and uploading.


FOLDER STRUCTURE
----------------

Use numbered folders for weeks and days:
  01. Week 1/
    01. Day 1/
    02. Day 2/
  02. Week 2/
    01. Day 1/

The numbers control the order. The text after the number is the display name.


CONTENT FOLDERS
---------------

Inside each day folder, create these subfolders as needed:

  content/          - Learner materials (PDFs, videos, documents)
  lesson_plan/      - Trainer guides (visible only to trainers)
  quiz/             - Quiz files in CSV format
  assignment/       - Assignment instructions (PDFs, documents)
  roleplay/         - Roleplay scenarios (visible only to trainers)
  rubric/           - Grading rubrics (visible only to trainers)


QUIZ FORMAT
-----------

Quizzes must be CSV files with these columns:
  - question_type (multichoice, truefalse, shortanswer, essay)
  - question_text
  - option_a, option_b, option_c, option_d (for multichoice)
  - correct_answer
  - points

Example quiz.csv:
  question_type,question_text,option_a,option_b,option_c,option_d,correct_answer,points
  multichoice,"What is 2+2?",3,4,5,6,B,1
  truefalse,"The sky is blue",True,False,,,A,1


FILE TYPES SUPPORTED
--------------------

Documents: .pdf, .doc, .docx, .ppt, .pptx, .txt
Media: .mp4, .mov, .mp3, .wav
Quizzes: .csv


TIPS
----

1. You don't need all folders - only create the ones you need
2. File names become activity names (e.g., "Introduction.pdf" → "Introduction")
3. Use clear, descriptive file names
4. Keep folder names short but meaningful
5. Delete this README.txt before zipping


NEED HELP?
----------

Contact your system administrator or refer to the import documentation.
